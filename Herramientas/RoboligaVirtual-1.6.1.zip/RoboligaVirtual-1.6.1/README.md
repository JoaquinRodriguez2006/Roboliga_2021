# Roboliga Virtual
**Sitio oficial de la Roboliga Virtual**

Para más información visitá nuestra [wiki](https://github.com/gzabala/RoboligaVirtual/wiki)

Y no dejes de sumarte a la comunidad en [Discord](https://discord.gg/SZ24uFV6sq)
